package com.example.morkince.okasyonv2.activities.holder

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.TextView
import com.example.morkince.okasyonv2.R

class TransactionViewHolder (itemView: View, var context: Context): RecyclerView.ViewHolder(itemView) {
    fun bindItem(string: String) {
        var textView = itemView.findViewById<TextView>(R.id.textView_transaction_chat)
        textView.text = string

    }
}