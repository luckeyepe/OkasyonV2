package com.example.morkince.okasyonv2.activities.client_activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.example.morkince.okasyonv2.R;

public class FoundEventDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_found_event_details);

    }
}
