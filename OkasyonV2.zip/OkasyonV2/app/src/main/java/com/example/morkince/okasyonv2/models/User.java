package com.example.morkince.okasyonv2.models;

public class User {
    String user_first_name = null;
    String user_last_name = null;
    String user_gender = null;
    String user_birth_date = null;
    String user_contact_no = null;
    String user_email = null;
    String user_profPic = null;
    String user_role = null;
}
