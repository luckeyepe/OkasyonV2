package com.example.morkince.okasyonv2.activities.signup_organizer_activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.morkince.okasyonv2.R

class SignUpOrganizerPart1Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_sign_up_organizer_part1)
    }
}
